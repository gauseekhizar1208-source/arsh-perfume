<!doctype html>
<html lang="en-IN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', setting('business_name', 'Arsh Perfume').' | '.setting('tagline'))</title>
    <meta name="description" content="@yield('meta_description', 'Premium attars, roll-on perfumes and fragrance oils from Arsh Perfume. Feel the best quality.')">
    <link rel="canonical" href="@yield('canonical', url()->current())">
    <meta property="og:site_name" content="{{ setting('business_name', 'Arsh Perfume') }}">
    <meta property="og:type" content="@yield('og_type', 'website')">
    <meta property="og:title" content="@yield('title', 'Arsh Perfume')">
    <meta property="og:description" content="@yield('meta_description', 'Premium attars and perfumes.')">
    <meta property="og:url" content="{{ url()->current() }}">
    @hasSection('og_image')
        <meta property="og:image" content="@yield('og_image')">
    @endif
    <link rel="icon" href="{{ asset('images/brand/arsh-logo.jpg') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,400;0,500;0,600;1,400;1,500&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('head')
</head>
<body class="storefront flex min-h-screen flex-col">
<a href="#main" class="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-50 focus:bg-gold focus:px-4 focus:py-2 focus:text-ink">Skip to content</a>

<div class="announcement">A world of fragrance. A scent that's yours. <a href="{{ route('shop') }}">Discover Arsh &rarr;</a></div>
<header class="store-header sticky top-0 z-40 border-b border-line" x-data="{ open: false }" @keydown.escape.window="open = false">
    <div class="container-x flex h-20 items-center justify-between gap-6">
        <a href="{{ route('home') }}" class="flex items-center gap-3" aria-label="{{ setting('business_name') }} home">
            <img src="{{ asset('images/brand/arsh-logo.jpg') }}" alt="" class="logo-blend h-10 w-auto" width="60" height="40">
            <span class="brand-wordmark">ARSH<span>THE FRAGRANCE HOUSE</span></span>
        </a>

        <nav class="hidden items-center gap-7 text-sm uppercase tracking-widest text-muted lg:flex" aria-label="Main">
            <a href="{{ route('shop') }}" class="hover:text-gold {{ request()->routeIs('shop') ? 'text-gold' : '' }}">All Fragrances</a>
            <a href="{{ route('collections.index') }}" class="hover:text-gold">Collections</a>
            <a href="{{ route('track-order') }}" class="hover:text-gold">Track Order</a>
            <a href="{{ route('pages.about') }}" class="hover:text-gold">About</a>
            <a href="{{ route('contact') }}" class="hover:text-gold">Contact</a>
        </nav>

        <div class="flex items-center gap-4 text-sm">
            <form action="{{ route('shop') }}" method="get" class="hidden md:block" role="search">
                <label for="site-search" class="sr-only">Search products</label>
                <input id="site-search" name="q" type="search" value="{{ request('q') }}" placeholder="Search" class="input w-44 py-2">
            </form>
            @auth
                @if(auth()->user()->isAdmin())
                    <a href="{{ route('admin.dashboard') }}" class="hidden font-medium text-gold hover:text-gold-soft sm:inline">Dashboard</a>
                @endif
                <a href="{{ route('account') }}" class="hidden hover:text-gold sm:inline">Account</a>
                <a href="{{ route('wishlist.index') }}" class="hidden hover:text-gold sm:inline">Wishlist</a>
            @else
                <a href="{{ route('login') }}" class="hidden hover:text-gold sm:inline">Sign in</a>
            @endauth
            <a href="{{ route('cart.index') }}" class="relative hover:text-gold" aria-label="Cart, {{ $cartCount ?? 0 }} items">
                Cart
                @if(($cartCount ?? 0) > 0)
                    <span class="ml-1 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-gold px-1 text-[11px] font-semibold text-ink">{{ $cartCount }}</span>
                @endif
            </a>
            <button type="button" class="menu-toggle lg:hidden" @click="open = !open" :aria-expanded="open" aria-controls="mobile-nav" aria-label="Toggle menu">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 6h18M3 12h18M3 18h18"/></svg>
            </button>
        </div>
    </div>

    <nav id="mobile-nav" x-cloak x-show="open" class="border-t border-line bg-panel lg:hidden" aria-label="Mobile">
        <div class="container-x flex flex-col gap-1 py-4 text-sm uppercase tracking-widest">
            <form action="{{ route('shop') }}" method="get" role="search" class="mb-3"><label for="mobile-search" class="sr-only">Search fragrances</label><input id="mobile-search" type="search" name="q" class="input" placeholder="Find your fragrance" value="{{ request('q') }}"></form>
            <a class="py-2" href="{{ route('shop') }}">Shop</a>
            <a class="py-2" href="{{ route('collections.index') }}">Collections</a>
            <a class="py-2" href="{{ route('track-order') }}">Track Order</a>
            <a class="py-2" href="{{ route('pages.about') }}">About</a>
            <a class="py-2" href="{{ route('contact') }}">Contact</a>
            @auth
                <a class="py-2" href="{{ route('account') }}">My Account</a>
                <a class="py-2" href="{{ route('wishlist.index') }}">Wishlist</a>
                @if(auth()->user()->isAdmin())<a class="py-2 text-gold" href="{{ route('admin.dashboard') }}">Admin</a>@endif
                <form method="post" action="{{ route('logout') }}">@csrf<button class="py-2 text-left">Sign out</button></form>
            @else
                <a class="py-2" href="{{ route('login') }}">Sign in</a>
                <a class="py-2" href="{{ route('register') }}">Create account</a>
            @endauth
        </div>
    </nav>
</header>

@if(app()->environment('local', 'testing') && app(\App\Services\RazorpayService::class)->isSimulated())
    <div class="bg-gold/15 px-4 py-2 text-center text-xs text-gold-soft">Razorpay payments are in test mode.@if(app(\App\Services\UpiPaymentService::class)->isAvailable()) Direct UPI QR payments transfer real money to the receiving account shown.@endif</div>
@endif

<main id="main" class="flex-1">
    <div class="container-x {{ session('status') || session('error') || $errors->any() ? 'pt-6' : '' }}">
        @if(session('status'))<div class="alert-ok mb-4" role="status">{{ session('status') }}</div>@endif
        @if(session('error'))<div class="alert-error mb-4" role="alert">{{ session('error') }}</div>@endif
        @if($errors->any())
            <div class="alert-error mb-4" role="alert">Please check the highlighted fields and try again.</div>
        @endif
    </div>
    @yield('content')
</main>

<footer class="store-footer mt-24 border-t border-line bg-panel">
    <div class="container-x grid gap-10 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div>
            <p class="font-display text-xl tracking-[0.2em]">ARSH PERFUME</p>
            <p class="mt-3 text-sm text-muted">{{ setting('tagline') }}</p>
            @if(setting('social_instagram') || setting('social_facebook') || setting('social_youtube'))
                <ul class="mt-5 flex gap-4 text-sm text-muted">
                    @if(setting('social_instagram'))<li><a class="hover:text-gold" href="{{ setting('social_instagram') }}" rel="noopener" target="_blank">Instagram</a></li>@endif
                    @if(setting('social_facebook'))<li><a class="hover:text-gold" href="{{ setting('social_facebook') }}" rel="noopener" target="_blank">Facebook</a></li>@endif
                    @if(setting('social_youtube'))<li><a class="hover:text-gold" href="{{ setting('social_youtube') }}" rel="noopener" target="_blank">YouTube</a></li>@endif
                </ul>
            @endif
        </div>
        <div class="text-sm">
            <p class="mb-4 font-medium uppercase tracking-widest text-white">Help</p>
            <ul class="space-y-2 text-muted">
                <li><a class="hover:text-gold" href="{{ route('pages.faq') }}">FAQ</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.shipping') }}">Shipping Policy</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.returns') }}">Returns &amp; Refunds</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.cancellation') }}">Cancellation Policy</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.payment') }}">Payment Information</a></li>
                <li><a class="hover:text-gold" href="{{ route('track-order') }}">Track Your Order</a></li>
            </ul>
        </div>
        <div class="text-sm">
            <p class="mb-4 font-medium uppercase tracking-widest text-white">Legal</p>
            <ul class="space-y-2 text-muted">
                <li><a class="hover:text-gold" href="{{ route('pages.privacy') }}">Privacy Policy</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.terms') }}">Terms &amp; Conditions</a></li>
                <li><a class="hover:text-gold" href="{{ route('pages.about') }}">About Us</a></li>
                @foreach(collect(preg_split('/\R/', (string) setting('footer_links')))->filter() as $line)
                    @php([$label, $url] = array_pad(explode('|', $line, 2), 2, '#'))
                    <li><a class="hover:text-gold" href="{{ trim($url) }}">{{ trim($label) }}</a></li>
                @endforeach
            </ul>
        </div>
        <div class="text-sm text-muted">
            <p class="mb-4 font-medium uppercase tracking-widest text-white">Contact</p>
            @if(setting('business_address'))<p class="mb-2 whitespace-pre-line">{{ setting('business_address') }}</p>@endif
            @if(setting('contact_email'))<p class="mb-2"><a class="hover:text-gold" href="mailto:{{ setting('contact_email') }}">{{ setting('contact_email') }}</a></p>@endif
            @if(setting('contact_phone'))<p class="mb-2"><a class="hover:text-gold" href="tel:{{ setting('contact_phone') }}">{{ setting('contact_phone') }}</a></p>@endif
            @if(setting('business_hours'))<p>{{ setting('business_hours') }}</p>@endif
            @if(setting('gstin'))<p class="mt-3 text-xs">GSTIN: {{ setting('gstin') }}</p>@endif
        </div>
    </div>
    <div class="border-t border-line">
        <div class="container-x flex flex-col gap-2 py-6 text-xs text-muted sm:flex-row sm:justify-between">
            <p>&copy; {{ date('Y') }} {{ setting('business_name', 'Arsh Perfume') }}. All rights reserved.</p>
            <p>{{ setting('footer_text') }}</p>
        </div>
    </div>
</footer>
</body>
</html>
