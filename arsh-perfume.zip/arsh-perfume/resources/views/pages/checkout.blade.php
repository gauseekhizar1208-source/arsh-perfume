@extends('layouts.app')

@section('title', 'Checkout | Arsh Perfume')

@section('content')
@php($t = $summary['totals'])
<div class="container-x py-12">
    <h1 class="section-title">Checkout</h1>

    <form method="post" action="{{ route('checkout.store') }}" class="mt-10 grid gap-10 lg:grid-cols-[1fr_380px]" novalidate>
        @csrf
        <input type="hidden" name="idempotency_key" value="{{ $idempotencyKey }}">

        <div class="space-y-10">
            <section class="card space-y-6 p-6 sm:p-8" aria-labelledby="contact-h">
                <h2 id="contact-h" class="font-display text-lg">Contact</h2>
                <div class="grid gap-5 sm:grid-cols-2">
                    <div><label class="label" for="name">Full name</label><input id="name" name="name" class="input @error('name') input-error @enderror" value="{{ old('name', auth()->user()?->name ?? '') }}" required autocomplete="name">@error('name')<p class="field-error">{{ $message }}</p>@enderror</div>
                    <div><label class="label" for="email">Email</label><input id="email" name="email" type="email" class="input @error('email') input-error @enderror" value="{{ old('email', auth()->user()?->email ?? '') }}" required autocomplete="email">@error('email')<p class="field-error">{{ $message }}</p>@enderror</div>
                    <div><label class="label" for="phone">Mobile number</label><input id="phone" name="phone" type="tel" class="input @error('phone') input-error @enderror" value="{{ old('phone', auth()->user()?->phone ?? '') }}" required autocomplete="tel" inputmode="tel">@error('phone')<p class="field-error">{{ $message }}</p>@enderror</div>
                </div>
            </section>

            <section class="card space-y-6 p-6 sm:p-8" aria-labelledby="addr-h" x-data="{ pick: '' }">
                <h2 id="addr-h" class="font-display text-lg">Delivery address</h2>

                @if($addresses->isNotEmpty())
                    <div class="grid gap-3 sm:grid-cols-2">
                        @foreach($addresses as $a)
                            <button type="button" class="border border-line p-4 text-left text-sm hover:border-gold"
                                    data-address="{{ json_encode(['address_line1' => $a->address_line1, 'address_line2' => $a->address_line2, 'city' => $a->city, 'state' => $a->state, 'postal_code' => $a->postal_code, 'phone' => $a->phone]) }}"
                                    onclick="fillAddress(this)">
                                <span class="font-medium">{{ $a->label ?: 'Saved address' }}</span>
                                <span class="mt-1 block text-muted">{{ $a->oneLine() }}</span>
                            </button>
                        @endforeach
                    </div>
                @endif

                <div class="grid gap-5 sm:grid-cols-2">
                    <div class="sm:col-span-2"><label class="label" for="address_line1">Address line 1</label><input id="address_line1" name="address_line1" class="input" value="{{ old('address_line1') }}" required autocomplete="address-line1">@error('address_line1')<p class="field-error">{{ $message }}</p>@enderror</div>
                    <div class="sm:col-span-2"><label class="label" for="address_line2">Address line 2 (optional)</label><input id="address_line2" name="address_line2" class="input" value="{{ old('address_line2') }}" autocomplete="address-line2"></div>
                    <div><label class="label" for="city">City</label><input id="city" name="city" class="input" value="{{ old('city') }}" required autocomplete="address-level2">@error('city')<p class="field-error">{{ $message }}</p>@enderror</div>
                    <div><label class="label" for="state">State</label>
                        <select id="state" name="state" class="input" required autocomplete="address-level1">
                            <option value="">Select state</option>
                            @foreach($states as $s)<option value="{{ $s }}" @selected(old('state') === $s)>{{ $s }}</option>@endforeach
                        </select>@error('state')<p class="field-error">{{ $message }}</p>@enderror
                    </div>
                    <div><label class="label" for="postal_code">PIN code</label><input id="postal_code" name="postal_code" inputmode="numeric" maxlength="6" class="input" value="{{ old('postal_code') }}" required autocomplete="postal-code">@error('postal_code')<p class="field-error">{{ $message }}</p>@enderror</div>
                    <div class="sm:col-span-2"><label class="label" for="notes">Delivery notes (optional)</label><textarea id="notes" name="notes" rows="2" class="input" maxlength="500">{{ old('notes') }}</textarea></div>
                </div>
            </section>

            <section class="card space-y-4 p-6 sm:p-8" aria-labelledby="pay-h">
                <h2 id="pay-h" class="font-display text-lg">Payment method</h2>
                @if($codEnabled)
                    <label class="flex cursor-pointer items-start gap-3 border border-line p-4 has-[:checked]:border-gold">
                        <input type="radio" name="payment_method" value="cod" class="mt-1 accent-[#C8A24D]" @checked(old('payment_method', 'cod') === 'cod') required>
                        <span><span class="block font-medium">Cash on Delivery</span><span class="text-xs text-muted">Pay in cash when your order arrives.</span></span>
                    </label>
                @endif
                @if($onlineEnabled)
                    <label class="flex cursor-pointer items-start gap-3 border border-line p-4 has-[:checked]:border-gold">
                        <input type="radio" name="payment_method" value="razorpay" class="mt-1 accent-[#C8A24D]" @checked(old('payment_method') === 'razorpay')>
                        <span><span class="block font-medium">Pay Online</span><span class="text-xs text-muted">UPI, cards, netbanking and wallets via Razorpay. Card details never touch our servers.</span></span>
                    </label>
                @endif
                @if($upiEnabled)
                    <label class="flex cursor-pointer items-start gap-3 border border-line p-4 has-[:checked]:border-gold">
                        <input type="radio" name="payment_method" value="upi" class="mt-1 accent-[#C8A24D]" @checked(old('payment_method', !$codEnabled && !$onlineEnabled ? 'upi' : '') === 'upi') required>
                        <span><span class="block font-medium">Pay by UPI QR</span><span class="text-xs text-muted">Scan our QR using your UPI app, then submit the transaction reference. Payment is confirmed after we verify receipt.</span></span>
                    </label>
                @endif
                @error('payment_method')<p class="field-error">{{ $message }}</p>@enderror
            </section>
        </div>

        <aside class="card h-fit space-y-5 p-6 lg:sticky lg:top-28" aria-labelledby="os-h">
            <h2 id="os-h" class="font-display text-lg">Order summary</h2>
            <ul class="divide-y divide-line text-sm">
                @foreach($summary['lines'] as $line)
                    <li class="flex justify-between gap-3 py-3">
                        <span>{{ $line['name'] }} <span class="text-muted">({{ $line['variant_name'] }}) &times; {{ $line['quantity'] }}</span></span>
                        <span>{{ money($line['line_total']) }}</span>
                    </li>
                @endforeach
            </ul>
            <dl class="space-y-2 border-t border-line pt-4 text-sm">
                <div class="flex justify-between"><dt class="text-muted">Subtotal</dt><dd>{{ money($t['subtotal']) }}</dd></div>
                @if($t['discount_paise'] > 0)<div class="flex justify-between text-ok"><dt>Coupon {{ $summary['coupon']?->code }}</dt><dd>&minus;{{ money($t['discount']) }}</dd></div>@endif
                <div class="flex justify-between"><dt class="text-muted">Shipping</dt><dd>{{ $t['shipping_paise'] > 0 ? money($t['shipping']) : 'Free' }}</dd></div>
                <div class="flex justify-between border-t border-line pt-3 text-base"><dt>Total payable</dt><dd class="text-gold">{{ money($t['total']) }}</dd></div>
            </dl>
            <button class="btn-gold w-full" @disabled(count($summary['issues']))>Place Order</button>
            @if(count($summary['issues']))<p class="alert-error text-xs">Some items in your cart are unavailable. <a class="underline" href="{{ route('cart.index') }}">Review cart</a>.</p>@endif
            <p class="text-xs text-muted">By placing your order you agree to our <a class="text-gold hover:underline" href="{{ route('pages.terms') }}">terms</a> and <a class="text-gold hover:underline" href="{{ route('pages.cancellation') }}">cancellation policy</a>.</p>
        </aside>
    </form>
</div>

<script>
    function fillAddress(btn) {
        const d = JSON.parse(btn.dataset.address);
        ['address_line1', 'address_line2', 'city', 'state', 'postal_code', 'phone'].forEach(k => {
            const el = document.getElementById(k) || document.querySelector(`[name="${k}"]`);
            if (el) el.value = d[k] ?? '';
        });
    }
</script>
@endsection
