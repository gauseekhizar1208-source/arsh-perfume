@extends('layouts.app')

@section('title', 'Order Placed | Arsh Perfume')

@section('content')
<div class="container-x py-16">
    <div class="card mx-auto max-w-2xl space-y-6 p-8 text-center sm:p-12">
        <p class="text-xs uppercase tracking-[0.3em] text-gold">Thank you</p>
        <h1 class="section-title">Your order is placed</h1>
        <p class="text-sm text-muted">Order number <span class="font-medium text-white">{{ $order->order_number }}</span></p>

        @if($order->payment_method === 'razorpay' && ! $order->isPaid())
            <p class="alert-info text-left">Your payment is still being confirmed. This page updates when it is received. Your order will be cancelled automatically if payment is not completed in time.</p>
        @endif

        <dl class="grid gap-4 border-y border-line py-6 text-left text-sm sm:grid-cols-2">
            @if($order->payment_method === 'upi' && $order->payment_status === 'pending' && $order->status === 'pending')
                <div class="alert-info sm:col-span-2"><p>Your UPI payment is awaiting manual verification. If you already paid, submit your transaction reference and do not pay again.</p><a href="{{ route('checkout.upi', $order) }}" class="text-link">UPI QR &amp; payment reference &rarr;</a></div>
            @endif
            <div><dt class="label">Total</dt><dd class="text-gold">{{ money($order->grand_total) }}</dd></div>
            <div><dt class="label">Payment</dt><dd>{{ $order->payment_method_label }} &middot; {{ $order->payment_status_label }}</dd></div>
            <div class="sm:col-span-2"><dt class="label">Delivering to</dt><dd>{{ $order->shippingAddressOneLine() }}</dd></div>
        </dl>

        <p class="text-sm text-muted">We have emailed the details to <span class="text-white">{{ $order->email }}</span>.</p>
        <div class="flex flex-col justify-center gap-3 sm:flex-row">
            <a href="{{ route('track-order') }}" class="btn-outline">Track your order</a>
            <a href="{{ route('shop') }}" class="btn-gold">Continue shopping</a>
        </div>
    </div>
</div>
@endsection
